#include "flightdialog.h"
#include "ui_flightdialog.h"
#include <QMessageBox>

FlightDialog::FlightDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::FlightDialog)
{
    ui->setupUi(this);
}

FlightDialog::~FlightDialog()
{
    delete ui;
}

// Slot for "Book a Flight"
void FlightDialog::on_pushButton_clicked()
{
    QMessageBox::information(this, "Booking", "Book a Flight functionality is under development!");
}

// Slot for "Flight Schedule"
void FlightDialog::on_pushButton_3_clicked()
{
    QMessageBox::information(this, "Schedule", "Flight Schedule functionality is under development!");
}
