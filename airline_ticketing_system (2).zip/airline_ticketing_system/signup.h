#ifndef SIGNUP_H
#define SIGNUP_H

#include <QDialog>
#include <QRegularExpressionValidator> // For email validation
#include <fstream> // For binary file handling

namespace Ui {
class SignUp;
}

class SignUp : public QDialog
{
    Q_OBJECT

public:
    explicit SignUp(QWidget *parent = nullptr);
    ~SignUp();

private slots:
    void on_signupButton_clicked(); // Slot for "Sign Up" button

private:
    Ui::SignUp *ui;

    // Helper function to save credentials to the binary file
    void saveCredentialsToFile(const QString &username, const QString &password, const QString &email);
};

#endif // SIGNUP_H
