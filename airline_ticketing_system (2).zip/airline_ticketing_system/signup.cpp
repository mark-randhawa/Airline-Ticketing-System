#include "signup.h"
#include "ui_signup.h"
#include <QMessageBox> // For error messages

SignUp::SignUp(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::SignUp)
{
    ui->setupUi(this);

    // Set placeholder text for line edits
    ui->usernameLineEdit->setPlaceholderText("Enter username");
    ui->passwordLineEdit->setPlaceholderText("Enter password");
    ui->emailLineEdit->setPlaceholderText("Enter email (e.g., abc@xyz.com)");

    // Set a regular expression validator for the email field
    QRegularExpression emailRegex(R"([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})");
    QRegularExpressionValidator *emailValidator = new QRegularExpressionValidator(emailRegex, this);
    ui->emailLineEdit->setValidator(emailValidator);
}

SignUp::~SignUp()
{
    delete ui;
}

// Save user credentials to the binary file
void SignUp::saveCredentialsToFile(const QString &username, const QString &password, const QString &email)
{
    // Open a binary file in append mode
    std::ofstream outFile("users.dat", std::ios::binary | std::ios::app);
    if (!outFile) {
        QMessageBox::critical(this, "Error", "Failed to open file for saving credentials!");
        return;
    }

    // Convert QString to std::string for binary storage
    std::string user = username.toStdString();
    std::string pass = password.toStdString();
    std::string mail = email.toStdString();

    // Write to the binary file
    size_t userLength = user.length();
    size_t passLength = pass.length();
    size_t mailLength = mail.length();

    outFile.write(reinterpret_cast<char*>(&userLength), sizeof(userLength));
    outFile.write(user.c_str(), userLength);
    outFile.write(reinterpret_cast<char*>(&passLength), sizeof(passLength));
    outFile.write(pass.c_str(), passLength);
    outFile.write(reinterpret_cast<char*>(&mailLength), sizeof(mailLength));
    outFile.write(mail.c_str(), mailLength);

    outFile.close();
}

// Slot for the "Sign Up" button
void SignUp::on_signupButton_clicked()
{
    QString username = ui->usernameLineEdit->text();
    QString password = ui->passwordLineEdit->text();
    QString email = ui->emailLineEdit->text();

    // Validate email format
    if (!ui->emailLineEdit->hasAcceptableInput()) {
        QMessageBox::warning(this, "Invalid Email", "Please enter a valid email address.");
        return;
    }

    if (username.isEmpty() || password.isEmpty() || email.isEmpty()) {
        QMessageBox::warning(this, "Incomplete Data", "All fields must be filled out.");
        return;
    }

    // Save credentials to the file
    saveCredentialsToFile(username, password, email);

    QMessageBox::information(this, "Success", "Sign up successful! Please log in with your new credentials.");
    this->close(); // Close the signup window
}
