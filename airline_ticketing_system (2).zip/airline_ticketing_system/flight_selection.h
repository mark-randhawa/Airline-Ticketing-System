#ifndef FLIGHT_SELECTION_H
#define FLIGHT_SELECTION_H

#include <QDialog>
#include <QVector>
#include <QString>

namespace Ui {
class flight_selection;
}

// Struct to hold flight information
struct FlightInfo {
    QString flightNumber;
    QString airline;
    QString departureTime;
    QString arrivalTime;
    double price;
};

class flight_selection : public QDialog
{
    Q_OBJECT

public:
    explicit flight_selection(QWidget *parent = nullptr);
    ~flight_selection();

    // Method to populate flights
    void displayFlights(const QVector<FlightInfo> &flights);

private:
    Ui::flight_selection *ui;

private slots:
    void handleFlightSelection(const FlightInfo &flight); // Slot for booking flight
    void saveFlightDetailsToFile(const FlightInfo &flight); // Method to save flight info to binary file
};

#endif // FLIGHT_SELECTION_H
