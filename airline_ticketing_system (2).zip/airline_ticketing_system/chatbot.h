#ifndef CHATBOT_H
#define CHATBOT_H

#include <QDialog>
#include <QMap> // For keyword-based responses

namespace Ui {
class chatbot;
}

class chatbot : public QDialog
{
    Q_OBJECT

public:
    explicit chatbot(QWidget *parent = nullptr);
    ~chatbot();

private slots:
    void on_sendButton_clicked(); // Handles sending user input
    void on_backButton_clicked(); // Handles going back to the previous screen

private:
    Ui::chatbot *ui;

    // Map to hold keyword-response pairs
    QMap<QString, QString> responses;

    // Helper function to process the query
    QString getResponse(const QString &query);
};

#endif // CHATBOT_H
