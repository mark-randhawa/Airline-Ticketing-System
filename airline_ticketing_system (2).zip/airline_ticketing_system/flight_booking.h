#ifndef FLIGHT_BOOKING_H
#define FLIGHT_BOOKING_H

#include <QDialog>
#include <QVector>
#include <QDate>
#include "flight_selection.h" // Include to access FlightInfo structure

namespace Ui {
class flight_booking;
}

class flight_booking : public QDialog
{
    Q_OBJECT

public:
    explicit flight_booking(QWidget *parent = nullptr);
    ~flight_booking();

private slots:
    void on_searchButton_clicked();
    void on_BackpushButton_clicked();

private:
    Ui::flight_booking *ui;

    void saveBookingDetailsToFile(const QString &from, const QString &to, int travelers, const QDate &date);
};

#endif // FLIGHT_BOOKING_H
