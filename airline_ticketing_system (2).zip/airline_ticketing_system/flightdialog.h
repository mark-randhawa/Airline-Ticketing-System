#ifndef FLIGHTDIALOG_H
#define FLIGHTDIALOG_H

#include <QDialog>

namespace Ui {
class FlightDialog;
}

class FlightDialog : public QDialog
{
    Q_OBJECT

public:
    explicit FlightDialog(QWidget *parent = nullptr);
    ~FlightDialog();

private slots:
    void on_pushButton_clicked();  // Slot for "Book a Flight"
    void on_pushButton_3_clicked();  // Slot for "Flight Schedule"

private:
    Ui::FlightDialog *ui;
};

#endif // FLIGHTDIALOG_H
