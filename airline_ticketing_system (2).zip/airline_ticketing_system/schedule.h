#ifndef SCHEDULE_H
#define SCHEDULE_H

#include <QDialog>

namespace Ui {
class schedule;
}

class schedule : public QDialog
{
    Q_OBJECT

public:
    explicit schedule(QWidget *parent = nullptr);
    ~schedule();

private slots:
    void on_BackpushButton_clicked();

private:
    Ui::schedule *ui;
    void setupTable(); // Function to set up the table
};

#endif // SCHEDULE_H
