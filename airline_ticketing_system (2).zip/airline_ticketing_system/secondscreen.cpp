#include "secondscreen.h"
#include "ui_secondscreen.h"
#include "schedule.h" // Include the header for schedule screen
#include "chatbot.h"  // Include the chatbot header for the bot button

secondscreen::secondscreen(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::secondscreen)
    , flightBookingScreen(nullptr) // Initialize pointer to nullptr
{
    ui->setupUi(this);
}

secondscreen::~secondscreen()
{
    delete ui;
}

void secondscreen::on_bookButton_clicked()
{
    // Open flight booking screen
    flightBookingScreen = new flight_booking(this);
    flightBookingScreen->show();
    this->hide(); // Hide the second screen
}

void secondscreen::on_bookButton_2_clicked()
{
    qDebug() << "Flight Schedule button clicked!";
    schedule *scheduleScreen = new schedule();
    scheduleScreen->show();
    this->hide(); // Optional: hides the current screen
}

void secondscreen::on_bot_clicked()
{
    // Open the chatbot window when the bot button is clicked
    chatbot *chatBotScreen = new chatbot(this); // Create chatbot window
    chatBotScreen->show();  // Show the chatbot window
    this->hide();  // Hide the current secondscreen
}
