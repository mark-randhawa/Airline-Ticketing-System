#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include "signup.h"
#include "secondscreen.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , chatBotDialog(nullptr) // Initialize chatbot pointer
{
    ui->setupUi(this);

    // Set placeholder text for the line edits
    ui->usernameLineEdit->setPlaceholderText("Enter username");
    ui->passwordLineEdit->setPlaceholderText("Enter password");

    // Set the password field to hide the entered text
    ui->passwordLineEdit->setEchoMode(QLineEdit::Password);
}

MainWindow::~MainWindow()
{
    delete ui;
    if (chatBotDialog) delete chatBotDialog; // Clean up chatbot dialog
}

void MainWindow::on_loginButton_clicked()
{
    QString username = ui->usernameLineEdit->text();
    QString password = ui->passwordLineEdit->text();

    // Open the binary file for reading
    std::ifstream inFile("users.dat", std::ios::binary);
    if (!inFile) {
        QMessageBox::warning(this, "Error", "No user data found. Please sign up first.");
        return;
    }

    bool loginSuccess = false;

    // Read user data from the file
    while (!inFile.eof()) {
        size_t userLength, passLength, mailLength;
        std::string user, pass, mail;

        inFile.read(reinterpret_cast<char*>(&userLength), sizeof(userLength));
        if (inFile.eof()) break; // Prevents double loop at EOF

        user.resize(userLength);
        inFile.read(&user[0], userLength);

        inFile.read(reinterpret_cast<char*>(&passLength), sizeof(passLength));
        pass.resize(passLength);
        inFile.read(&pass[0], passLength);

        inFile.read(reinterpret_cast<char*>(&mailLength), sizeof(mailLength));
        mail.resize(mailLength);
        inFile.read(&mail[0], mailLength);

        // Check if credentials match
        if (username.toStdString() == user && password.toStdString() == pass) {
            loginSuccess = true;
            break;
        }
    }

    inFile.close();

    if (loginSuccess) {
        // Login successful
        secondscreen *secondScreen = new secondscreen(this);
        secondScreen->show();
        this->hide();
    } else {
        QMessageBox::warning(this, "Login Failed", "Invalid username or password.");
    }
}

void MainWindow::on_cancelButton_clicked()
{
    this->close(); // Close the current window
}

void MainWindow::on_Signup_clicked()
{
    SignUp *signupScreen = new SignUp(this);
    signupScreen->exec();
}

void MainWindow::on_bot_clicked()
{
    if (!chatBotDialog) {
        chatBotDialog = new chatbot(this); // Create chatbot dialog
    }
    chatBotDialog->show();
    this->hide();
}
