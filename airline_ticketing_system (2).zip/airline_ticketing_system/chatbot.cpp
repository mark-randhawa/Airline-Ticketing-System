#include "chatbot.h"
#include "ui_chatbot.h"

chatbot::chatbot(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::chatbot)
{
    ui->setupUi(this);

    // Populate keyword-response pairs
    responses["booking"] = "To book a flight, first log-in through your credentials, then click 'book a flight'";
    responses["book"] = "To book a flight, first log-in through your credentials, then click 'book a flight'";
    responses["schedule"] = "You can view the flight schedule after logging in";
    responses["scheduling"] = "You can view the flight schedule after logging in";
    responses["cancel"] = "This feature is coming ! meanwhile for cancellation contact us at 0xxx343xx.";
    responses["price"] = "Flight prices vary depending on the route and airline.";
    responses["help"] = "You can ask about booking, schedule, cancellations, or pricing.";
    responses["status"] = "Flight status can be checked in the 'Flight Schedule' section.";
    responses["contact"] = "For further assistance, contact our support at famz@airline.com.";
    responses["login"] = "To log in, use your registered username and password.";
    responses["log in"] = "To log in, use your registered username and password.";
    responses["signup"] = "To sign up, fill out the form in the 'Sign Up' section.";
    responses["sign up"] = "To sign up, fill out the form in the 'Sign Up' section.";
    responses["refund"] = "Refunds are processed within 7-10 business days after cancellation.";
    responses["luggage"] = "Each passenger is allowed 15kg of luggage. Additional charges apply for extra weight.";
    responses["check-in"] = "Online check-in opens 24 hours before the scheduled flight departure.";
    responses["meals"] = "Complimentary meals are provided on long-haul flights. Snacks are available for purchase.";
    responses["seats"] = "Seat selection can be made during check-in.";
    responses["seat"] = "Seat selection can be made during check-in.";
    responses["emergency"] = "For emergencies during the flight, please inform the cabin crew immediately.";

    // Set up UI styles
    ui->display->setReadOnly(true); // Display should be read-only
    ui->display->setStyleSheet("color: black; font-weight: bold;");
    //ui->display->setStyleSheet("background-color: #FFF8DC; font: 12px 'Bahnschrift';");
    //ui->inputlineEdit->setStyleSheet("background-color: #FFFFFF; font: 12px 'Bahnschrift';");
}

chatbot::~chatbot()
{
    delete ui;
}

void chatbot::on_sendButton_clicked()
{
    QString userQuery = ui->inputlineEdit->text(); // Get user input
    if (userQuery.isEmpty()) {
        ui->display->append("You: (No input provided)");
        ui->display->append("Chatbot: Please type something to get started.");
        return;
    }

    ui->display->append("You: " + userQuery);

    // Get a response based on the query
    QString response = getResponse(userQuery);
    ui->display->append("Chatbot: " + response);

    // Clear input line
    ui->inputlineEdit->clear();
}

void chatbot::on_backButton_clicked()
{
    this->close(); // Close chatbot window
    parentWidget()->show(); // Show the parent window
}

QString chatbot::getResponse(const QString &query)
{
    QString response;
    bool found = false;

    // Match all keywords in the query
    for (const QString &keyword : responses.keys()) {
        if (query.contains(keyword, Qt::CaseInsensitive)) {
            if (!response.isEmpty()) {
                response += "\n"; // Add a newline for multiple responses
            }
            response += responses[keyword];
            found = true;
        }
    }

    if (!found) {
        response = "I'm sorry, I didn't understand that. Please ask something else or rephrase your query.";
    }

    return response;
}

