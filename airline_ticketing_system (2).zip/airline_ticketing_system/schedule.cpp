#include "schedule.h"
#include "ui_schedule.h"
#include "secondscreen.h" // Include header for secondscreen

schedule::schedule(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::schedule)
{
    ui->setupUi(this);
    setupTable(); // Call the function to set up the table with flight schedule data
}

schedule::~schedule()
{
    delete ui;
}

void schedule::setupTable()
{
    // Set up table column headers
    ui->scheduleTable->setColumnCount(8);
    ui->scheduleTable->setHorizontalHeaderLabels(
        {"Flight Number", "Departure City", "Arrival City", "Date",
         "Departure Time", "Arrival Time", "Airline", "Status"});

    // Add 5 rows of flight schedule data
    ui->scheduleTable->setRowCount(5);

    // Row 1
    ui->scheduleTable->setItem(0, 0, new QTableWidgetItem("PK301"));
    ui->scheduleTable->setItem(0, 1, new QTableWidgetItem("Karachi"));
    ui->scheduleTable->setItem(0, 2, new QTableWidgetItem("Lahore"));
    ui->scheduleTable->setItem(0, 3, new QTableWidgetItem("2024-07-21"));
    ui->scheduleTable->setItem(0, 4, new QTableWidgetItem("10:00 AM"));
    ui->scheduleTable->setItem(0, 5, new QTableWidgetItem("12:00 PM"));
    ui->scheduleTable->setItem(0, 6, new QTableWidgetItem("PIA"));
    ui->scheduleTable->setItem(0, 7, new QTableWidgetItem("On Time"));

    // Additional rows...

    // Example Row 2
    // Row 2
    ui->scheduleTable->setItem(1, 0, new QTableWidgetItem("PK305"));
    ui->scheduleTable->setItem(1, 1, new QTableWidgetItem("Islamabad"));
    ui->scheduleTable->setItem(1, 2, new QTableWidgetItem("Karachi"));
    ui->scheduleTable->setItem(1, 3, new QTableWidgetItem("2024-07-22"));
    ui->scheduleTable->setItem(1, 4, new QTableWidgetItem("02:00 PM"));
    ui->scheduleTable->setItem(1, 5, new QTableWidgetItem("04:30 PM"));
    ui->scheduleTable->setItem(1, 6, new QTableWidgetItem("AirBlue"));
    ui->scheduleTable->setItem(1, 7, new QTableWidgetItem("Delayed"));

    // Row 3
    ui->scheduleTable->setItem(2, 0, new QTableWidgetItem("ATR712"));
    ui->scheduleTable->setItem(2, 1, new QTableWidgetItem("Islamabad"));
    ui->scheduleTable->setItem(2, 2, new QTableWidgetItem("Gilgit"));
    ui->scheduleTable->setItem(2, 3, new QTableWidgetItem("2024-07-23"));
    ui->scheduleTable->setItem(2, 4, new QTableWidgetItem("05:00 PM"));
    ui->scheduleTable->setItem(2, 5, new QTableWidgetItem("09:00 PM"));
    ui->scheduleTable->setItem(2, 6, new QTableWidgetItem("Serene Air"));
    ui->scheduleTable->setItem(2, 7, new QTableWidgetItem("On Time"));

    // Row 4
    ui->scheduleTable->setItem(3, 0, new QTableWidgetItem("PK707"));
    ui->scheduleTable->setItem(3, 1, new QTableWidgetItem("Quetta"));
    ui->scheduleTable->setItem(3, 2, new QTableWidgetItem("Islamabad"));
    ui->scheduleTable->setItem(3, 3, new QTableWidgetItem("2024-07-24"));
    ui->scheduleTable->setItem(3, 4, new QTableWidgetItem("07:00 AM"));
    ui->scheduleTable->setItem(3, 5, new QTableWidgetItem("09:00 AM"));
    ui->scheduleTable->setItem(3, 6, new QTableWidgetItem("PIA"));
    ui->scheduleTable->setItem(3, 7, new QTableWidgetItem("On Time"));

    // Row 5
    ui->scheduleTable->setItem(4, 0, new QTableWidgetItem("PA145"));
    ui->scheduleTable->setItem(4, 1, new QTableWidgetItem("Multan"));
    ui->scheduleTable->setItem(4, 2, new QTableWidgetItem("Karachi"));
    ui->scheduleTable->setItem(4, 3, new QTableWidgetItem("2024-07-25"));
    ui->scheduleTable->setItem(4, 4, new QTableWidgetItem("08:30 AM"));
    ui->scheduleTable->setItem(4, 5, new QTableWidgetItem("10:00 AM"));
    ui->scheduleTable->setItem(4, 6, new QTableWidgetItem("AirSial"));
    ui->scheduleTable->setItem(4, 7, new QTableWidgetItem("On Time"));

    // Other cells follow the same pattern...

    // Row 3, Row 4, etc...
}

void schedule::on_BackpushButton_clicked()
{
    // Create a new secondscreen instance
    secondscreen *secondScreen = new secondscreen(this->parentWidget());
    secondScreen->show(); // Show the second screen
    this->close();        // Close the schedule screen


}
