#include "flight_selection.h"
#include "ui_flight_selection.h"
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QMessageBox>
#include <QFile>
#include <QFile>
#include <QTextStream>


flight_selection::flight_selection(QWidget *parent)
    : QDialog(parent), ui(new Ui::flight_selection)
{
    ui->setupUi(this);
}

flight_selection::~flight_selection()
{
    delete ui;
}

void flight_selection::displayFlights(const QVector<FlightInfo> &flights)
{
    // Clear existing items in gridLayout
    QLayoutItem *child;
    while ((child = ui->gridLayout->takeAt(0)) != nullptr) {
        delete child->widget(); // Delete the widget
        delete child;           // Delete the layout item
    }

    int row = 0, col = 0;

    for (const auto &flight : flights) {
        // Create a QWidget to hold flight details
        QWidget *flightCard = new QWidget(this);
        QVBoxLayout *layout = new QVBoxLayout(flightCard);

        // Add flight details
        layout->addWidget(new QLabel("Flight Number: " + flight.flightNumber));
        layout->addWidget(new QLabel("Airline: " + flight.airline));
        layout->addWidget(new QLabel("Departure: " + flight.departureTime));
        layout->addWidget(new QLabel("Arrival: " + flight.arrivalTime));
        layout->addWidget(new QLabel("Price: PKR " + QString::number(flight.price)));

        // Add the "Select Flight" button
        QPushButton *selectButton = new QPushButton("Select Flight");
        layout->addWidget(selectButton);

        // Connect button to handle selection
        connect(selectButton, &QPushButton::clicked, [this, flight]() {
            handleFlightSelection(flight);
        });

        // Apply the flight card's stylesheet
        flightCard->setStyleSheet(
            "background-color: #FFF8DC; /* Cream color */"
            "border: 2px solid #8B4513; /* SaddleBrown border */"
            "border-radius: 4px; /* Rounded corners */"
            "padding: 1px; /* Padding for a neat look */"
            "color: black; /* Set text color to black for better visibility */"
            );

        // Apply the button's stylesheet
        selectButton->setStyleSheet(
            "QPushButton {"
            "    background-color: #8B4513;" /* SaddleBrown color */
            "    color: white;" /* White text */
            "    border: 2px solid #5C2E0E;" /* Darker brown border */
            "    border-radius: 8px;" /* Rounded corners */
            "    padding: 1px 2px;" /* Padding for a neat look */
            "    font: bold 12px 'Bahnschrift';" /* Bold font */
            "    text-align: center;" /* Center text alignment */
            "}"
            "QPushButton:hover {"
            "    background-color: #A0522D;" /* Slightly lighter brown on hover */
            "    border: 2px solid #5C2E0E;" /* Keep the border color consistent */
            "    color: #FFF8DC;" /* Light cream color for text on hover */
            "}"
            "QPushButton:pressed {"
            "    background-color: #5C2E0E;" /* Dark brown when button is pressed */
            "    border: 2px solid #3E1F0A;" /* Darker border when pressed */
            "}"
            );


        // Add the flight card to the grid layout
        ui->gridLayout->addWidget(flightCard, row, col);

        // Update grid position
        col++;
        if (col >= 2) { // Two columns
            col = 0;
            row++;
        }
    }
}

void flight_selection::handleFlightSelection(const FlightInfo &flight)
{
    // Save flight selection details to file
    saveFlightDetailsToFile(flight);

    // Create the message box
    QMessageBox *msgBox = new QMessageBox(this);
    msgBox->setIcon(QMessageBox::Information);
    msgBox->setWindowTitle("Flight Selected");
    msgBox->setText("You selected:\n"
                    "Flight Number: " + flight.flightNumber + "\n" +
                    "Airline: " + flight.airline + "\n" +
                    "Departure: " + flight.departureTime + "\n" +
                    "Arrival: " + flight.arrivalTime + "\n" +
                    "Price: PKR " + QString::number(flight.price));

    msgBox->setStyleSheet(
        "QMessageBox {"
        "    color: black;" /* Set font color for the entire message box */
        "}"
        "QLabel {"
        "    color: black;" /* Ensure labels inside the message box have black font */
        "}"
        );
    // Add an OK button
    QPushButton *okButton = msgBox->addButton(QMessageBox::Ok);

    // Connect the OK button to close only the message box, not the parent dialog
    connect(okButton, &QPushButton::clicked, [msgBox]() {
        msgBox->close();
    });

    // Show the message box
    msgBox->show();
}






void flight_selection::saveFlightDetailsToFile(const FlightInfo &flight)
{
    QFile file("flightSelection.dat");  // Text file to store flight details

    if (!file.open(QIODevice::Append | QIODevice::Text)) {  // Open in text mode
        QMessageBox::critical(this, "File Error", "Failed to save flight details.");
        return;
    }

    QTextStream out(&file);  // Create a QTextStream for text-based file operations
    // Write the flight information to the file in text format
    out << "Flight Number: " << flight.flightNumber << "\n"
        << "Airline: " << flight.airline << "\n"
        << "Departure Time: " << flight.departureTime << "\n"
        << "Arrival Time: " << flight.arrivalTime << "\n"
        << "Price: " << flight.price << "\n\n";  // Add newline between entries for readability

    file.close();  // Close the file after writing
}

