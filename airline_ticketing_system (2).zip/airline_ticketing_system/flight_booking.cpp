#include "flight_booking.h"
#include "ui_flight_booking.h"
#include "secondscreen.h"
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QRandomGenerator> // For random number generation
#include <QVector>
#include "flight_selection.h" // Include FlightInfo structure

flight_booking::flight_booking(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::flight_booking)
{
    ui->setupUi(this);
}

flight_booking::~flight_booking()
{
    delete ui;
}

void flight_booking::on_searchButton_clicked()
{
    QStringList validCities = {
        "Islamabad", "Karachi", "Lahore", "Peshawar", "Quetta",
        "Multan", "Faisalabad", "Sialkot", "Gwadar", "Skardu",
        "Gilgit",  "Dera Ghazi Khan", "Sukkur", "Rahim Yar Khan",
        "Bahawalpur"
    };

    QString from = ui->FromlineEdit->text().trimmed();
    QString to = ui->TolineEdit->text().trimmed();
    int travelers = ui->TravlrEdit->text().toInt();
    QDate date = ui->dateEdit->date();

    // Ensure that 'from' and 'to' cities are not the same
    if (from.compare(to, Qt::CaseInsensitive) == 0) {
        QMessageBox *msgBox = new QMessageBox(this);
        msgBox->setText("The departure and destination cities cannot be the same.");
        msgBox->setIcon(QMessageBox::Warning);
        msgBox->setStyleSheet(

            "QLabel {"
            "    color: black;" /* Ensure labels inside the message box have black font */
            "}"
            );
        msgBox->exec();
        return;
    }

    if (from.isEmpty() || to.isEmpty() || travelers <= 0) {
        QMessageBox *msgBox = new QMessageBox(this);
        msgBox->setText("Please fill in all fields with valid data!");
        msgBox->setIcon(QMessageBox::Warning);
        msgBox->setStyleSheet(

            "QLabel {"
            "    color: black;"
            "}"
            );
        msgBox->exec();
        return;
    }

    if (!validCities.contains(from, Qt::CaseInsensitive)) {
        QMessageBox *msgBox = new QMessageBox(this);
        msgBox->setText("The departure city must have a valid airport in Pakistan.");
        msgBox->setIcon(QMessageBox::Warning);
        msgBox->setStyleSheet(

            "QLabel {"
            "    color: black;"
            "}"
            );
        msgBox->exec();
        return;
    }
    if (!validCities.contains(to, Qt::CaseInsensitive)) {
       QMessageBox *msgBox = new QMessageBox(this);
        msgBox->setText("The destination city must have a valid airport in Pakistan.");
        msgBox->setIcon(QMessageBox::Warning);
        msgBox->setStyleSheet(

            "QLabel {"
            "    color: black;"
            "}"
            );
        msgBox->exec();
        return;
    }

    // Save details to a file
    saveBookingDetailsToFile(from, to, travelers, date);

    // Generate random flights
    QVector<FlightInfo> flights;
    QStringList airlines = {"PIA", "AirBlue", "SereneAir", "AirSial"};
    QRandomGenerator *randGen = QRandomGenerator::global(); // Random number generator

    int numFlights = randGen->bounded(1, 5); // Random number of flights (1 to 4)
    for (int i = 0; i < numFlights; ++i) {
        FlightInfo flight;
        flight.flightNumber = "PK" + QString::number(randGen->bounded(100, 1000));
        flight.airline = airlines[randGen->bounded(airlines.size())];
        flight.departureTime = QString::number(randGen->bounded(6, 12)) + ":00 AM";
        flight.arrivalTime = QString::number(randGen->bounded(12, 18)) + ":00 PM";
        flight.price = randGen->bounded(5000, 10001); // Random price between 5000 and 10000
        flights.append(flight);
    }

    // Open the flight_selection UI
    flight_selection *flightSelect = new flight_selection(this);
    flightSelect->displayFlights(flights);
    flightSelect->exec();
}


void flight_booking::on_BackpushButton_clicked()
{
    secondscreen *secondScreen = new secondscreen(this->parentWidget());
    secondScreen->show();
    this->close(); // Close the current window
}

void flight_booking::saveBookingDetailsToFile(const QString &from, const QString &to, int travelers, const QDate &date)
{
    QFile file("bookingDetails.dat");
    if (!file.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::critical(this, "File Error", "Failed to save booking details.");
        return;
    }

    QTextStream out(&file);
    out << "From: " << from << "\n";
    out << "To: " << to << "\n";
    out << "Travelers: " << travelers << "\n";
    out << "Date: " << date.toString("dd/MM/yyyy") << "\n\n";
    file.close();
}
