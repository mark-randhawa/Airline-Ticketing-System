#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "chatbot.h"
#include "secondscreen.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_loginButton_clicked();
    void on_cancelButton_clicked();
    void on_Signup_clicked();
    void on_bot_clicked(); // Slot for opening the chatbot

private:
    Ui::MainWindow *ui;
    chatbot *chatBotDialog; // Pointer to chatbot dialog
};

#endif // MAINWINDOW_H
