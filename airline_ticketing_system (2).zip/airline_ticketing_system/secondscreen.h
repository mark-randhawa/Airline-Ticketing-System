#ifndef SECONDSCREEN_H
#define SECONDSCREEN_H

#include <QDialog>
#include "flight_booking.h"

namespace Ui {
class secondscreen;
}

class secondscreen : public QDialog
{
    Q_OBJECT

public:
    explicit secondscreen(QWidget *parent = nullptr);
    ~secondscreen();

private slots:
    void on_bookButton_clicked();
    void on_bookButton_2_clicked();

    void on_bot_clicked();

private:
    Ui::secondscreen *ui;
    flight_booking *flightBookingScreen; // Pointer to flight booking screen
};

#endif // SECONDSCREEN_H
